# Catholic-University-Data-Mining-2015
Catholic-University-Data-Mining-2015-Team Project

In Parser directory, you can read 2 cpp files: covering, j48. You can parse Weka's result text to C style code

Enjoy it!
